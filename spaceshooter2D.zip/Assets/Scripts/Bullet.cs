using UnityEngine;

public class Bullet : MonoBehaviour
{

    public int damage = 1;

    [Header("Bullet")]
    public float speed = 14f;
    public float lifeTime = 2.0f;

    // Boost ajout� au tir (ex: quand le joueur descend)
    float speedBoost = 0f;

    BulletPool pool;
    float topY;

    void Awake()
    {
        pool = GetComponentInParent<BulletPool>();
    }

    public void SetSpeedBoost(float boost)
    {
        speedBoost = boost;
    }

    void OnEnable()
    {
        // IMPORTANT avec le pooling : reset � chaque r�utilisation
        speedBoost = 0f;

        // Recalcule la limite haute (au cas o� cam�ra/zoom change)
        var cam = Camera.main;
        if (cam != null)
            topY = cam.transform.position.y + cam.orthographicSize + 1f;
        else
            topY = 9999f;

        CancelInvoke();
        Invoke(nameof(ReturnToPool), lifeTime); // s�curit�
    }

    void Update()
    {
        float v = speed + speedBoost;
        // s�curit� : on �vite de trop ralentir si boost n�gatif (normalement on n'en envoie pas)
        v = Mathf.Max(2f, v);

        transform.position += Vector3.up * v * Time.deltaTime;

        // Despawn d�s que c'est hors �cran
        if (transform.position.y > topY)
            ReturnToPool();
    }

    void ReturnToPool()
    {
        CancelInvoke();
        if (pool != null) pool.Return(gameObject);
        else gameObject.SetActive(false);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.TryGetComponent<Enemy>(out var enemy))
        {
            enemy.TakeHit(damage);
            ReturnToPool();
        }
    }

}
