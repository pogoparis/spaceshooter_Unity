public interface IDamageable
{
    void TakeHit(int damage);
}
